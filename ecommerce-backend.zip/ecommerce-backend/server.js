// Import required modules
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

// Create an instance of Express
const app = express();
const PORT = process.env.PORT || 5000; // Set the port for the server

// Middleware setup
app.use(cors()); // Enable CORS for all requests
app.use(bodyParser.json()); // Parse JSON request bodies

// Load mock product data from the JSON file
const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'mock-products.json')));

// Endpoint to get all products
app.get('/api/products', (req, res) => {
    res.json(products); // Send the product data as a JSON response
});

// Endpoint to get a specific product by ID
app.get('/api/products/:id', (req, res) => {
    const product = products.find(p => p.id === parseInt(req.params.id));
    if (product) {
        res.json(product); // Send the product details
    } else {
        res.status(404).json({ message: 'Product not found' }); // Handle 404 error
    }
});

// Simulate payment process
app.post('/api/checkout', (req, res) => {
    const { cardNumber, expiryDate, cvv } = req.body;

    if (cardNumber && expiryDate && cvv) {
        const isSuccess = Math.random() >= 0.5; // 50% chance of success
        if (isSuccess) {
            res.json({ message: 'Payment Successful!' }); // Send success message
        } else {
            res.status(400).json({ message: 'Payment Failed. Please try again.' }); // Send failure message
        }
    } else {
        res.status(400).json({ message: 'Invalid payment details.' }); // Handle invalid input
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`); // Log server start
});
